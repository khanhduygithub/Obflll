package dev.binclub.binscure.processors.constants.string

import dev.binclub.binscure.utils.ldcInt
import org.objectweb.asm.Opcodes.*
import org.objectweb.asm.tree.*

/**
 * Polymorphic String Encryption — each string gets its own cipher algorithm.
 *
 * Five algorithms (chosen randomly per-string):
 *
 *   ALG_XOR_CHAIN      – char[i] ^ keys[i % keys.size] ^ classHash ^ methodHash
 *   ALG_ROT_KEY        – char[i] + (key + i) as char rotated
 *   ALG_MULTIPLY_XOR   – char[i] ^ (classHash * (i+1)) ^ methodHash
 *   ALG_DOUBLE_XOR     – char[i] ^ key ^ classHash, then ^ methodHash
 *   ALG_SHIFT_XOR      – char[i] ^ (key shl (i % 5)) ^ (classHash ushr (i % 3))
 *
 * The algorithm ID is embedded inside the encrypted string as a
 * leading "magic" char so the runtime decryptor can dispatch to the
 * correct branch without extra metadata.
 */

enum class PolyAlgorithm(val id: Int) {
    ALG_XOR_CHAIN(0),
    ALG_ROT_KEY(1),
    ALG_MULTIPLY_XOR(2),
    ALG_DOUBLE_XOR(3),
    ALG_SHIFT_XOR(4);

    companion object {
        fun fromId(id: Int): PolyAlgorithm = entries[id % entries.size]
        val ALL: Array<PolyAlgorithm> = entries.toTypedArray()
    }
}

/** Encrypt a single string with the given algorithm and return the cipher text (with magic header). */
fun polyEncrypt(
    original: String,
    algorithm: PolyAlgorithm,
    key: Int,
    keys: IntArray,
    classHash: Int,
    methodHash: Int
): String {
    val src = original.toCharArray()
    val out = CharArray(src.size + 1) // +1 for magic header

    // Header char encodes (algId XOR key) so it is not a plain index
    out[0] = ((algorithm.id xor (key and 0xFF)) and 0xFFFF).toChar()

    for (i in src.indices) {
        val c = src[i].code
        val enc = when (algorithm) {
            PolyAlgorithm.ALG_XOR_CHAIN ->
                c xor keys[i % keys.size] xor classHash xor methodHash

            PolyAlgorithm.ALG_ROT_KEY ->
                (c + key + i) and 0xFFFF

            PolyAlgorithm.ALG_MULTIPLY_XOR ->
                c xor (classHash * (i + 1)) xor methodHash

            PolyAlgorithm.ALG_DOUBLE_XOR ->
                (c xor key xor classHash) xor methodHash

            PolyAlgorithm.ALG_SHIFT_XOR ->
                c xor (key shl (i % 5)) xor (classHash ushr (i % 3))
        }
        out[i + 1] = (enc and 0xFFFF).toChar()
    }
    return String(out)
}

/** Verify that decrypt(encrypt(s)) == s at obfuscation time. */
fun polyDecryptVerify(
    cipher: String,
    algorithm: PolyAlgorithm,
    key: Int,
    keys: IntArray,
    classHash: Int,
    methodHash: Int
): String {
    val src = cipher.toCharArray()
    // src[0] is magic header — skip it
    val out = CharArray(src.size - 1)
    for (i in out.indices) {
        val c = src[i + 1].code
        val dec = when (algorithm) {
            PolyAlgorithm.ALG_XOR_CHAIN ->
                c xor keys[i % keys.size] xor classHash xor methodHash

            PolyAlgorithm.ALG_ROT_KEY ->
                (c - key - i) and 0xFFFF

            PolyAlgorithm.ALG_MULTIPLY_XOR ->
                c xor (classHash * (i + 1)) xor methodHash

            PolyAlgorithm.ALG_DOUBLE_XOR ->
                (c xor key xor classHash) xor methodHash

            PolyAlgorithm.ALG_SHIFT_XOR ->
                c xor (key shl (i % 5)) xor (classHash ushr (i % 3))
        }
        out[i] = (dec and 0xFFFF).toChar()
    }
    return String(out)
}

// ─── Bytecode helpers ────────────────────────────────────────────────────────
//
// Each algorithm gets its own static bytecode builder function that emits the
// decryption loop body into an InsnList.  The PolyDecryptGenerator calls the
// appropriate builder based on the switch case.

/**
 * Emit instructions that, given:
 *   LOCAL 0  = cipher String (Ljava/lang/String;)
 *   LOCAL 1  = global key    (I)
 *   LOCAL 2  = classHash     (I)
 *   LOCAL 3  = methodHash    (I)
 *   LOCAL 4  = keys array    ([I)
 *
 * produce:
 *   stack top = decrypted String
 *
 * Shared preamble is emitted by the caller (toCharArray, newArray, loop).
 * These helpers emit only the single-character XOR/arithmetic expression
 * for character at index `indexVar` (int local), result into `resultVar` (int local).
 */
fun emitAlgBody_XorChain(
    indexVar: Int,
    charVar: Int,
    resultVar: Int,
    keysArrayVar: Int,
    keyVar: Int,
    classHashVar: Int,
    methodHashVar: Int,
    keysSize: Int
): InsnList = InsnList().apply {
    // result = charVar ^ keys[index % keysSize] ^ classHash ^ methodHash
    add(VarInsnNode(ILOAD, charVar))
    add(VarInsnNode(ILOAD, indexVar))
    add(ldcInt(keysSize))
    add(InsnNode(IREM))
    add(VarInsnNode(ALOAD, keysArrayVar))
    add(InsnNode(SWAP))
    add(InsnNode(IALOAD))
    add(InsnNode(IXOR))
    add(VarInsnNode(ILOAD, classHashVar))
    add(InsnNode(IXOR))
    add(VarInsnNode(ILOAD, methodHashVar))
    add(InsnNode(IXOR))
    add(VarInsnNode(ISTORE, resultVar))
}

fun emitAlgBody_RotKey(
    indexVar: Int,
    charVar: Int,
    resultVar: Int,
    keyVar: Int
): InsnList = InsnList().apply {
    // result = (charVar - key - index) & 0xFFFF
    add(VarInsnNode(ILOAD, charVar))
    add(VarInsnNode(ILOAD, keyVar))
    add(InsnNode(ISUB))
    add(VarInsnNode(ILOAD, indexVar))
    add(InsnNode(ISUB))
    add(ldcInt(0xFFFF))
    add(InsnNode(IAND))
    add(VarInsnNode(ISTORE, resultVar))
}

fun emitAlgBody_MultiplyXor(
    indexVar: Int,
    charVar: Int,
    resultVar: Int,
    classHashVar: Int,
    methodHashVar: Int
): InsnList = InsnList().apply {
    // result = charVar ^ (classHash * (index+1)) ^ methodHash
    add(VarInsnNode(ILOAD, charVar))
    add(VarInsnNode(ILOAD, classHashVar))
    add(VarInsnNode(ILOAD, indexVar))
    add(InsnNode(ICONST_1))
    add(InsnNode(IADD))
    add(InsnNode(IMUL))
    add(InsnNode(IXOR))
    add(VarInsnNode(ILOAD, methodHashVar))
    add(InsnNode(IXOR))
    add(VarInsnNode(ISTORE, resultVar))
}

fun emitAlgBody_DoubleXor(
    charVar: Int,
    resultVar: Int,
    keyVar: Int,
    classHashVar: Int,
    methodHashVar: Int
): InsnList = InsnList().apply {
    // result = (charVar ^ key ^ classHash) ^ methodHash
    add(VarInsnNode(ILOAD, charVar))
    add(VarInsnNode(ILOAD, keyVar))
    add(InsnNode(IXOR))
    add(VarInsnNode(ILOAD, classHashVar))
    add(InsnNode(IXOR))
    add(VarInsnNode(ILOAD, methodHashVar))
    add(InsnNode(IXOR))
    add(VarInsnNode(ISTORE, resultVar))
}

fun emitAlgBody_ShiftXor(
    indexVar: Int,
    charVar: Int,
    resultVar: Int,
    keyVar: Int,
    classHashVar: Int
): InsnList = InsnList().apply {
    // result = charVar ^ (key << (index % 5)) ^ (classHash >>> (index % 3))
    add(VarInsnNode(ILOAD, charVar))
    // key << (index % 5)
    add(VarInsnNode(ILOAD, keyVar))
    add(VarInsnNode(ILOAD, indexVar))
    add(ldcInt(5))
    add(InsnNode(IREM))
    add(InsnNode(ISHL))
    add(InsnNode(IXOR))
    // ^ classHash >>> (index % 3)
    add(VarInsnNode(ILOAD, classHashVar))
    add(VarInsnNode(ILOAD, indexVar))
    add(ldcInt(3))
    add(InsnNode(IREM))
    add(InsnNode(IUSHR))
    add(InsnNode(IXOR))
    add(VarInsnNode(ISTORE, resultVar))
}
