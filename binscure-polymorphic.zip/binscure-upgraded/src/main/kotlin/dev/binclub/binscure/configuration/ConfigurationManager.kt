package dev.binclub.binscure.configuration

import com.sksamuel.hoplite.ConfigLoaderBuilder
import com.sksamuel.hoplite.addFileSource
import dev.binclub.binscure.api.RootConfiguration
import java.io.File

/**
 * @author cookiedragon234 25/Jan/2020
 *
 * UPGRADED: Hoplite 1.x -> 2.x API changes:
 *   - ConfigLoader.Builder() -> ConfigLoaderBuilder.default()
 *   - addSource(PropertySource.file(...)) -> addFileSource(...)
 *   - loadConfigOrThrow<T>(list) -> loadConfigOrThrow<T>()
 */
object ConfigurationManager {
    lateinit var rootConfig: RootConfiguration

    fun parse(configFile: File): RootConfiguration {
        rootConfig = ConfigLoaderBuilder.default()
            .addFileSource(configFile)
            .build()
            .loadConfigOrThrow<RootConfiguration>()
        return rootConfig
    }
}
