package dev.binclub.binscure.processors.constants.string

import dev.binclub.binscure.CObfuscator
import dev.binclub.binscure.utils.ldcInt
import dev.binclub.binscure.utils.newLabel
import org.objectweb.asm.Opcodes.*
import org.objectweb.asm.tree.*

/**
 * Generates the polymorphic decryption method that is injected into the
 * decrypt helper class.
 *
 * Method signature (static):
 *   public static String polyDecrypt(String cipher, int classHash, int methodHash)
 *
 * Runtime flow:
 *  1. Read magic header char from cipher[0] to recover algId.
 *  2. Read global key from keysField (obfuscated as algId XOR key).
 *  3. Convert cipher substring [1..] to char[].
 *  4. Allocate output char[].
 *  5. Loop over each char, dispatch via tableswitch to correct algorithm.
 *  6. Store result, construct new String, cache and return.
 *
 * Local variable map:
 *   0  = cipher String
 *   1  = classHash (int)
 *   2  = methodHash (int)
 *   3  = algId (int)           recovered from header
 *   4  = key (int)             global XOR key
 *   5  = keys int[]            reference to keysField
 *   6  = srcChars char[]       cipher.substring(1).toCharArray()
 *   7  = dstChars char[]       output
 *   8  = index (int)           loop counter
 *   9  = curChar (int)         current source character
 *   10 = result (int)          decrypted character value
 */
object PolyDecryptGenerator {

    const val METHOD_NAME = "polyDecrypt"
    const val METHOD_DESC = "(Ljava/lang/String;II)Ljava/lang/String;"

    fun generate(
        classNode: ClassNode,
        storageField: FieldNode,
        keysField: FieldNode,
        globalKey: Int,
        keysSize: Int
    ): MethodNode {
        val mn = MethodNode(
            ACC_PUBLIC + ACC_STATIC,
            METHOD_NAME,
            METHOD_DESC,
            null,
            null
        )

        // Local indices
        val lCipher      = 0
        val lClassHash   = 1
        val lMethodHash  = 2
        val lAlgId       = 3
        val lKey         = 4
        val lKeysArr     = 5
        val lSrcChars    = 6
        val lDstChars    = 7
        val lIndex       = 8
        val lCurChar     = 9
        val lResult      = 10

        val loopStart   = newLabel()
        val loopEnd     = newLabel()
        val storeChar   = newLabel()
        val buildString = newLabel()

        // --- algorithm dispatch labels ---
        val lblXorChain    = newLabel()
        val lblRotKey      = newLabel()
        val lblMultiplyXor = newLabel()
        val lblDoubleXor   = newLabel()
        val lblShiftXor    = newLabel()
        val lblDefault     = newLabel()

        val insnList = InsnList().apply {

            // ── 1. Recover algId from magic header ──────────────────────────
            // algId = (cipher.charAt(0) ^ (key & 0xFF)) % NUM_ALGORITHMS
            // But we haven't loaded key yet — we embed (algId XOR (key&0xFF)) in the
            // header at encrypt time, so we need the key first.
            //
            // Key is stored in keysField initialiser as (keysSize XOR key) then loaded.
            // For the runtime we just inline the globalKey constant directly — it is
            // already an obfuscated int literal in the class.
            //
            // cipher[0] = (algId XOR (globalKey & 0xFF)) & 0xFFFF
            // => algId   = (cipher[0] XOR (globalKey & 0xFF)) % NUM_ALGORITHMS

            add(VarInsnNode(ALOAD, lCipher))
            add(ldcInt(0))
            add(MethodInsnNode(INVOKEVIRTUAL, "java/lang/String", "charAt", "(I)C", false))
            add(ldcInt(globalKey and 0xFF))
            add(InsnNode(IXOR))
            add(ldcInt(PolyAlgorithm.ALL.size))
            add(InsnNode(IREM))
            add(VarInsnNode(ISTORE, lAlgId))

            // ── 2. Load global key constant ──────────────────────────────────
            add(ldcInt(globalKey))
            add(VarInsnNode(ISTORE, lKey))

            // ── 3. Load keys array ───────────────────────────────────────────
            add(FieldInsnNode(GETSTATIC, classNode.name, keysField.name, keysField.desc))
            add(VarInsnNode(ASTORE, lKeysArr))

            // ── 4. Build source char array from cipher[1..] ─────────────────
            add(VarInsnNode(ALOAD, lCipher))
            add(ldcInt(1))
            add(VarInsnNode(ALOAD, lCipher))
            add(MethodInsnNode(INVOKEVIRTUAL, "java/lang/String", "length", "()I", false))
            add(MethodInsnNode(INVOKEVIRTUAL, "java/lang/String", "substring", "(II)Ljava/lang/String;", false))
            add(MethodInsnNode(INVOKEVIRTUAL, "java/lang/String", "toCharArray", "()[C", false))
            add(VarInsnNode(ASTORE, lSrcChars))

            // Allocate output array
            add(VarInsnNode(ALOAD, lSrcChars))
            add(InsnNode(ARRAYLENGTH))
            add(IntInsnNode(NEWARRAY, T_CHAR))
            add(VarInsnNode(ASTORE, lDstChars))

            // ── 5. Loop ──────────────────────────────────────────────────────
            add(ldcInt(0))
            add(VarInsnNode(ISTORE, lIndex))

            add(loopStart)
            add(VarInsnNode(ILOAD, lIndex))
            add(VarInsnNode(ALOAD, lSrcChars))
            add(InsnNode(ARRAYLENGTH))
            add(JumpInsnNode(IF_ICMPGE, loopEnd))

            // Load current char into lCurChar
            add(VarInsnNode(ALOAD, lSrcChars))
            add(VarInsnNode(ILOAD, lIndex))
            add(InsnNode(CALOAD))
            add(VarInsnNode(ISTORE, lCurChar))

            // Dispatch on algId
            add(VarInsnNode(ILOAD, lAlgId))
            add(TableSwitchInsnNode(
                0,
                PolyAlgorithm.ALL.size - 1,
                lblDefault,
                lblXorChain, lblRotKey, lblMultiplyXor, lblDoubleXor, lblShiftXor
            ))

            // ── ALG 0: XOR_CHAIN ─────────────────────────────────────────────
            add(lblXorChain)
            addAll(emitAlgBody_XorChain(lIndex, lCurChar, lResult, lKeysArr, lKey, lClassHash, lMethodHash, keysSize))
            add(JumpInsnNode(GOTO, storeChar))

            // ── ALG 1: ROT_KEY ───────────────────────────────────────────────
            add(lblRotKey)
            addAll(emitAlgBody_RotKey(lIndex, lCurChar, lResult, lKey))
            add(JumpInsnNode(GOTO, storeChar))

            // ── ALG 2: MULTIPLY_XOR ──────────────────────────────────────────
            add(lblMultiplyXor)
            addAll(emitAlgBody_MultiplyXor(lIndex, lCurChar, lResult, lClassHash, lMethodHash))
            add(JumpInsnNode(GOTO, storeChar))

            // ── ALG 3: DOUBLE_XOR ────────────────────────────────────────────
            add(lblDoubleXor)
            addAll(emitAlgBody_DoubleXor(lCurChar, lResult, lKey, lClassHash, lMethodHash))
            add(JumpInsnNode(GOTO, storeChar))

            // ── ALG 4: SHIFT_XOR ─────────────────────────────────────────────
            add(lblShiftXor)
            addAll(emitAlgBody_ShiftXor(lIndex, lCurChar, lResult, lKey, lClassHash))
            add(JumpInsnNode(GOTO, storeChar))

            // ── DEFAULT (should not happen) ──────────────────────────────────
            add(lblDefault)
            add(VarInsnNode(ILOAD, lCurChar))
            add(VarInsnNode(ISTORE, lResult))

            // ── Store decrypted char ─────────────────────────────────────────
            add(storeChar)
            add(VarInsnNode(ALOAD, lDstChars))
            add(VarInsnNode(ILOAD, lIndex))
            add(VarInsnNode(ILOAD, lResult))
            add(InsnNode(I2C))
            add(InsnNode(CASTORE))

            add(IincInsnNode(lIndex, 1))
            add(JumpInsnNode(GOTO, loopStart))

            // ── 6. Build result String ───────────────────────────────────────
            add(loopEnd)
            add(buildString)

            // Cache in storageField map
            add(FieldInsnNode(GETSTATIC, classNode.name, storageField.name, storageField.desc))
            add(VarInsnNode(ALOAD, lCipher))

            add(TypeInsnNode(NEW, "java/lang/String"))
            add(InsnNode(DUP))
            add(VarInsnNode(ALOAD, lDstChars))
            add(MethodInsnNode(INVOKESPECIAL, "java/lang/String", "<init>", "([C)V", false))
            add(InsnNode(DUP_X2))

            add(MethodInsnNode(
                INVOKEVIRTUAL,
                "java/util/concurrent/ConcurrentHashMap",
                "put",
                "(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;",
                false
            ))
            add(InsnNode(POP)) // discard old value
            add(InsnNode(ARETURN))
        }

        mn.instructions.add(insnList)
        classNode.methods.add(mn)
        return mn
    }
}

// Helper to add all instructions from another InsnList
private fun InsnList.addAll(other: InsnList) {
    val it = other.iterator()
    while (it.hasNext()) add(it.next())
}
